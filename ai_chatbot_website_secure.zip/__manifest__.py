{
    "name": "AI Chatbot Website",
    "version": "1.0",
    "category": "Website",
    "summary": "Chatbot usando frontend puro sem eval",
    "depends": ["website"],
    "assets": {},
    "data": ["views/chatbot_template.xml"],
    "installable": True,
    "application": False,
}

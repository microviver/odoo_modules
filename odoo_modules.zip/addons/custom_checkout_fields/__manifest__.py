{
    "name": "Custom Checkout Fields",
    "version": "1.0",
    "author": "Wadiana",
    "depends": ["website_sale"],
    "data": [
        "views/website_sale_checkout.xml",
        "views/res_partner_views.xml"
    ],
    "installable": True,
    "application": False
}
